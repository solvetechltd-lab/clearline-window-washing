import { siteConfig } from '@/config/site';

export const metadata = {
  title: 'Privacy Policy | Clearline Window Co.',
  description: 'Our privacy policy and how we protect your information.',
};

export default function PrivacyPage() {
  return (
    <div className="min-h-screen py-12 bg-white">
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-navy mb-8">Privacy Policy</h1>

        <div className="prose prose-sm max-w-none space-y-6 text-slate">
          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Introduction</h2>
            <p>
              At {siteConfig.name}, your privacy is important to us. This Privacy Policy explains how we collect, use, and protect your information when you visit our website and use our services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Information We Collect</h2>
            <p>We collect information you provide directly, such as:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Name, email, and phone number</li>
              <li>Address and location information</li>
              <li>Details about your service request</li>
              <li>Any additional information you provide in messages</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">How We Use Your Information</h2>
            <p>We use your information to:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Provide quotes and schedule services</li>
              <li>Communicate with you about your request</li>
              <li>Send confirmations and follow-ups</li>
              <li>Improve our services</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Information Sharing</h2>
            <p>
              We do not sell or share your personal information with third parties. We may share information with our email service provider (Resend) only to send you communications about your service request.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Data Security</h2>
            <p>
              We take reasonable precautions to protect your information. However, no method of transmission over the internet is 100% secure. Please contact us if you have any security concerns.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Cookies</h2>
            <p>
              Our website may use cookies to enhance your experience. You can control cookie preferences through your browser settings.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Your Rights</h2>
            <p>
              You have the right to access, correct, or delete your personal information. Contact us at {siteConfig.email} to exercise these rights.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Contact Us</h2>
            <p>
              If you have questions about this Privacy Policy or our privacy practices, please contact us:
            </p>
            <div className="bg-aqua rounded-lg p-4 mt-3">
              <p>
                <strong>{siteConfig.name}</strong>
                <br />
                Phone:{' '}
                <a href={`tel:${siteConfig.phone.replace(/\D/g, '')}`} className="text-sky-blue">
                  {siteConfig.phone}
                </a>
                <br />
                Email:{' '}
                <a href={`mailto:${siteConfig.email}`} className="text-sky-blue">
                  {siteConfig.email}
                </a>
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-navy mb-3">Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. The date of the last update will be reflected at the bottom of this page.
            </p>
          </section>

          <div className="text-xs text-gray-400 pt-8 border-t border-gray-200">
            <p>Last updated: {new Date().toLocaleDateString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
