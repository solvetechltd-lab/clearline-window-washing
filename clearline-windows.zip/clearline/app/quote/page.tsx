import { Suspense } from 'react';
import { QuoteForm } from '@/components/QuoteForm';
import { CheckCircle } from 'lucide-react';
import { siteConfig } from '@/config/site';

interface QuotePageProps {
  searchParams: Promise<{ service?: string }>;
}

async function QuotePageContent({ searchParams }: QuotePageProps) {
  const params = await searchParams;
  const initialService = params.service || '';

  return (
    <div className="min-h-screen py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-navy mb-4">
            Get Your Free Quote in 60 Seconds
          </h1>
          <p className="text-lg text-slate max-w-2xl mx-auto">
            Tell us a little about your property. We'll reply within 2 business hours, usually sooner.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form - Main */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl border border-gray-200 p-8">
              <QuoteForm initialService={initialService} />
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* What Happens Next */}
            <div className="bg-aqua rounded-2xl p-6">
              <h3 className="font-bold text-navy mb-4">What Happens Next</h3>
              <ol className="space-y-3">
                {[
                  'Request a free quote',
                  'We confirm within 2 business hours',
                  'Pick a time and we clean',
                ].map((step, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white text-sky-blue font-bold flex items-center justify-center text-sm">
                      {i + 1}
                    </span>
                    <span className="text-sm text-navy">{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Guarantee Badge */}
            <div className="bg-navy text-white rounded-2xl p-6 text-center">
              <div className="text-3xl mb-2">✓</div>
              <h4 className="font-bold mb-2">100% Satisfaction</h4>
              <p className="text-sm">
                Streak-free results guaranteed. Free re-clean within 7 days if we miss a spot.
              </p>
            </div>

            {/* Call Box */}
            <div className="bg-sky-blue text-white rounded-2xl p-6 text-center">
              <p className="text-sm mb-3">Prefer to talk?</p>
              <a
                href={`tel:${siteConfig.phone.replace(/\D/g, '')}`}
                className="block text-2xl font-bold mb-3 hover:underline"
              >
                {siteConfig.phone}
              </a>
              <p className="text-sm">
                {siteConfig.hours.mon_fri}<br />
                Sat: {siteConfig.hours.sat}<br />
                {siteConfig.hours.sun}
              </p>
            </div>

            {/* Mini Testimonial */}
            <div className="border-2 border-gray-200 rounded-2xl p-6">
              <div className="flex gap-1 mb-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className="text-sun-yellow">★</span>
                ))}
              </div>
              <p className="text-sm text-slate italic mb-3">
                "Best window cleaners I've used. Fair pricing and work is guaranteed."
              </p>
              <p className="text-sm font-semibold text-navy">— Lisa T.</p>
            </div>

            {/* Promo */}
            <div className="bg-sun-yellow rounded-2xl p-6 text-center">
              <p className="text-sm font-semibold text-navy mb-2">
                New customer special
              </p>
              <p className="text-2xl font-bold text-navy mb-2">
                10% Off
              </p>
              <p className="text-sm text-navy">
                First cleaning<br />
                Code: <strong>{siteConfig.promo.code}</strong>
              </p>
            </div>

            {/* Photo Upload Note */}
            <div className="bg-gray-100 rounded-2xl p-6">
              <p className="text-sm text-navy mb-2">
                <strong>Quick way to get a quote:</strong>
              </p>
              <p className="text-sm text-slate">
                Text photos of your property to {siteConfig.phone} for an even faster quote!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default async function QuotePage({ searchParams }: QuotePageProps) {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <QuotePageContent searchParams={searchParams} />
    </Suspense>
  );
}

export const metadata = {
  title: 'Free Window Cleaning Quote | Clearline Window Co.',
  description: 'Get a free quote in 60 seconds. No obligation, no fees. We respond within 2 business hours.',
};
