import { Phone, Mail, Clock, MapPin, Building } from 'lucide-react';
import { ContactForm } from '@/components/ContactForm';
import { siteConfig } from '@/config/site';

export const metadata = {
  title: 'Contact Clearline Window Co. | Window Cleaning Services',
  description: 'Get in touch with us. Questions? We\'re here to help. Call, email, or send us a message.',
};

export default function ContactPage() {
  return (
    <div className="min-h-screen py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-navy mb-4">
            Let's Talk Windows
          </h1>
          <p className="text-lg text-slate max-w-2xl mx-auto">
            Questions, custom jobs, or commercial accounts? We're happy to help.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl border border-gray-200 p-8">
              <h2 className="text-2xl font-bold text-navy mb-6">Send us a message</h2>
              <ContactForm />
            </div>
          </div>

          {/* Contact Cards */}
          <div className="space-y-6">
            {/* Phone */}
            <div className="bg-aqua rounded-2xl p-6">
              <Phone className="text-sky-blue mb-3" size={32} />
              <h3 className="font-bold text-navy mb-2">Call Us</h3>
              <a
                href={`tel:${siteConfig.phone.replace(/\D/g, '')}`}
                className="text-2xl font-bold text-sky-blue hover:underline"
              >
                {siteConfig.phone}
              </a>
            </div>

            {/* Text */}
            <div className="bg-aqua rounded-2xl p-6">
              <Mail className="text-sky-blue mb-3" size={32} />
              <h3 className="font-bold text-navy mb-2">Text or Email</h3>
              <p className="text-sm text-navy mb-3">
                <strong>Text:</strong> {siteConfig.phone}
              </p>
              <p className="text-sm text-navy">
                <strong>Email:</strong>{' '}
                <a href={`mailto:${siteConfig.email}`} className="text-sky-blue hover:underline">
                  {siteConfig.email}
                </a>
              </p>
            </div>

            {/* Hours */}
            <div className="bg-aqua rounded-2xl p-6">
              <Clock className="text-sky-blue mb-3" size={32} />
              <h3 className="font-bold text-navy mb-3">Hours</h3>
              <div className="text-sm text-navy space-y-1">
                <p>
                  <strong>Mon-Fri:</strong> {siteConfig.hours.mon_fri}
                </p>
                <p>
                  <strong>Sat:</strong> {siteConfig.hours.sat}
                </p>
                <p>
                  <strong>Sun:</strong> {siteConfig.hours.sun}
                </p>
              </div>
            </div>

            {/* Service Area */}
            <div className="bg-aqua rounded-2xl p-6">
              <MapPin className="text-sky-blue mb-3" size={32} />
              <h3 className="font-bold text-navy mb-3">Service Area</h3>
              <p className="text-sm text-navy">
                {siteConfig.city} and surrounding areas
              </p>
              <p className="text-xs text-slate mt-3">
                Not sure? Give us a call—we may still be able to help!
              </p>
            </div>
          </div>
        </div>

        {/* Callouts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {/* Commercial */}
          <div className="bg-navy text-white rounded-2xl p-8">
            <Building className="mb-4" size={40} />
            <h3 className="text-2xl font-bold mb-3">Commercial Customers</h3>
            <p className="mb-4">
              Managing multiple properties? Ask about our custom recurring contracts and invoicing options.
            </p>
            <a
              href={`mailto:${siteConfig.email}?subject=Commercial%20Inquiry`}
              className="inline-block px-4 py-2 bg-sky-blue text-white rounded-lg font-semibold hover:opacity-90"
            >
              Inquire Now
            </a>
          </div>

          {/* Emergency */}
          <div className="bg-sky-blue text-white rounded-2xl p-8">
            <Clock className="mb-4" size={40} />
            <h3 className="text-2xl font-bold mb-3">Post-Construction Cleaning</h3>
            <p className="mb-4">
              Move-out cleaning or post-construction dust? Call us for a same-week estimate!
            </p>
            <a
              href={`tel:${siteConfig.phone.replace(/\D/g, '')}`}
              className="inline-block px-4 py-2 bg-white text-sky-blue rounded-lg font-semibold hover:opacity-90"
            >
              Call Now
            </a>
          </div>
        </div>

        {/* Map Placeholder */}
        <div className="bg-aqua rounded-2xl p-12 text-center mb-12">
          <MapPin className="mx-auto text-sky-blue mb-4" size={48} />
          <h3 className="text-2xl font-bold text-navy mb-2">Service Area Map</h3>
          <p className="text-slate">
            To add Google Maps embed: Replace this with your map embed code or use Google Maps Embed API.
          </p>
        </div>

        {/* Final CTA */}
        <div className="bg-navy text-white rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to get started?</h2>
          <p className="text-lg mb-6 opacity-95">
            Get a free quote in 60 seconds. No obligation.
          </p>
          <a
            href="/quote"
            className="inline-block px-8 py-3 bg-sky-blue text-white rounded-lg font-semibold hover:opacity-90"
          >
            Get Your Free Quote
          </a>
        </div>
      </div>
    </div>
  );
}
