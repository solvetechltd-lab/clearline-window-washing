import { NextRequest, NextResponse } from 'next/server';
import { contactFormSchema } from '@/lib/validation';
import {
  sendEmail,
  generateContactEmailHtml,
  generateContactConfirmationEmailHtml,
} from '@/lib/email';
import { checkRateLimit } from '@/lib/rateLimit';

export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
    if (!checkRateLimit(ip, 5, 600000)) {
      return NextResponse.json(
        { error: 'Too many requests. Please try again later.' },
        { status: 429 }
      );
    }

    const body = await request.json();

    // Validate form data
    const validData = contactFormSchema.parse(body);

    // Honeypot check
    if (validData.honeypot) {
      return NextResponse.json(
        { error: 'Invalid submission' },
        { status: 400 }
      );
    }

    // Send email to owner
    const ownerEmail = process.env.OWNER_EMAIL || 'owner@clearlinewindows.com';
    await sendEmail({
      to: ownerEmail,
      subject: `New Contact from ${validData.name} - ${validData.topic}`,
      html: generateContactEmailHtml(validData),
    });

    // Send confirmation email to customer
    await sendEmail({
      to: validData.email,
      subject: 'We Received Your Message - Clearline Window Co.',
      html: generateContactConfirmationEmailHtml(validData.name),
    });

    return NextResponse.json({
      success: true,
      message: 'Message received. We will get back to you soon.',
    });
  } catch (error) {
    console.error('Contact form error:', error);

    if (error instanceof Error && error.message.includes('validation')) {
      return NextResponse.json(
        { error: 'Invalid form data' },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'An error occurred. Please try again.' },
      { status: 500 }
    );
  }
}
